# Palm Line Segmentation > 2025-03-13 10:35am
https://universe.roboflow.com/palm-reading-test/palm-line-segmentation

Provided by a Roboflow user
License: CC BY 4.0

